/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.uniensinojavaswing.murilo.calculadorasimplesjava;

/**
 *
 * @author muril
 */
public class CalculadoraSimplesJava {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
